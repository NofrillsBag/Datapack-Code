scoreboard objectives add scrap_count dummy
function chocolate:scores