scoreboard objectives add db_timer dummy
scoreboard objectives add zero dummy zero
    scoreboard players set !fake zero 0