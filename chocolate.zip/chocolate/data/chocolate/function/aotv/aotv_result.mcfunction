playsound minecraft:entity.experience_orb.pickup ambient @s ~ ~ ~ 1 2


# 1. Apply Resistance (255 = 100% invulnerability)
effect give @s minecraft:resistance 2 255 true


# 3. Teleport player
tp @s ^ ^5 ^8
particle minecraft:happy_villager ^ ^1 ^8.5 0.5 0.5 0.5 1 20

# 4. Set cooldown
scoreboard players set @s db_timer 20
