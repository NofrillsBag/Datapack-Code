execute as @s run scoreboard players add @s db_timer 0
execute as @s at @s if score @s db_timer <= !fake zero run function chocolate:aotv/aotv_result


advancement revoke @s only chocolate:aotv_used


#tp @s ^ ^2 ^8
#advancement revoke @s only nutrionitionist:aotv_used